const loaderUtils = require('loader-utils');



const async = require('async');
const fs = require('fs');

// Example object with file names

const fileMap = {
    f1: 'file1.txt',
    f2: 'file2.txt',
    f3: 'file3.txt'
};


// asynchronous function that returns the file size in bytes
function getFileSizeInBytes(file, key, callback) {
    fs.stat(file, function(err, stat) {
        if (err) {
            return callback(err);
        }
        callback(null, stat.size);
    });
}


async.mapValues(fileMap, getFileSizeInBytes, function(err, result) {
    if (err) {
        console.log(err);
    } else {
        console.log(result);
        // result is now a map of file size in bytes for each file, e.g.
        // {
        //     f1: 1000,
        //     f2: 2000,
        //     f3: 3000
        // }
    }
});





// // Inside your loader function:
// function myCssLoader(content) {
//     const localName = extractClassNames(content); // Extract class names from CSS

//     // Create a hash based on the file location and class name
//     const hash = loaderUtils.getHashDigest(
//         context.resourcePath + localName,
//         'md5',
//         'base64',
//         5
//     );

//     // Use interpolateName to generate a unique filename
//     const className = loaderUtils.interpolateName(
//         context,
//         '[name]_[local]__[hash]',
//         options
//     );

//     // Remove the `.module` prefix if present
//     return className.replace('.module_', '_');
// }




// module.exports = myCssLoader;

